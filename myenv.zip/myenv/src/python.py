import re
import psycopg2
from psycopg2 import sql

try:
    # Estabelecendo conexão com o banco de dados
    conn = psycopg2.connect(host="localhost", dbname="redes", user="redes", password="123456")
    cursor = conn.cursor()

    # Definindo a consulta de inserção
    insert_query = sql.SQL("""
        INSERT INTO public.redes_scan(
             nome_rede, mac_ap, qualidade_link, nivel_sinal, canal, frequencia, lest_beacon
        ) VALUES ( %s, %s, %s, %s, %s, %s, %s);
    """)

    # Abrir o arquivo de log para leitura
    with open('log.txt', 'r') as file:
        nomeDaRede = None
        macAp = None
        qualidade = None
        nivelSinal = None
        frequencia = None
        canal = None
        lestBeancon = None

        for linha in file:
            # Verificar se a linha contém 'ESSID:'
            if 'ESSID:' in linha:
                nomeDaRede = linha.split("ESSID:")[-1].strip()  # Pegando apenas o valor após ESSID:
                print("Nome da Rede:", nomeDaRede)

            # Verificar se a linha contém 'Cell' (para pegar o MAC AP)
            if 'Cell ' in linha:
                macAp = linha.split("Cell")[-1].strip()  # Pegando o MAC AP
                print("MAC AP:", macAp)

            # Verificar se a linha contém 'Quality='
            if 'Quality=' in linha:
                qualidade = linha.split("Quality=")[-1].strip()  # Pegando a qualidade do link
                print("Qualidade do Link:", qualidade)

            # Verificar se a linha contém 'Frequency:'
            if 'Frequency:' in linha:
                frequencia = linha.split("Frequency:")[-1].strip()  # Pegando a frequência
                print("Frequência:", frequencia)

            if 'Signal level' in linha:
                nivelSinal = linha.split("Frequency:")[-1].strip()  # Pegando a sinal
                print("Frequência:", nivelSinal)


            # Verificar se a linha contém 'Extra: Last beacon:'
            if 'Extra: Last beacon:' in linha:
                lestBeancon = linha.split("Extra: Last beacon:")[-1].strip()  # Pegando o valor do beacon
                print("Last Beacon:", lestBeancon)

            # Verificar se a linha contém 'Channel:'
            if 'Channel:' in linha:
                canal = linha.split("Channel:")[-1].strip()  # Pegando o canal
                print("Canal:", canal)

            # Verificar se todos os dados estão completos para realizar o INSERT
            if nomeDaRede and macAp and qualidade and frequencia and canal and lestBeancon:
                # Insere no banco de dados apenas quando todos os dados estiverem presentes
                cursor.execute(insert_query, ( nomeDaRede, macAp, qualidade, nivelSinal, canal, frequencia, lestBeancon))
                print("Dados inseridos no banco de dados!")

                # Limpar variáveis para a próxima linha de dados
                nomeDaRede = macAp = qualidade = nivelSinal = frequencia = canal = lestBeancon = None

    # Commit para salvar as alterações
    conn.commit()

except Exception as e:
    print("Erro ao salvar no banco de dados:", e)
finally:
    # Fechar cursor e conexão
    if conn:
        cursor.close()
        conn.close()
